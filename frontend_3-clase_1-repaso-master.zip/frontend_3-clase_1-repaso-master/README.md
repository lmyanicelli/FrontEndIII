# REPASO PREVIO CON REACT

Realizaremos un ejercicio simple de refactorización de codigo. El fin es que puedan implementar conocimientos previos de JS y puedan volcarlos en un proyecto de React. Ademas veran ciertas funciones propias de React para que empiecen a familiarizarse.

## ¡A tener en cuenta!

Se trabajara solamente en el archivo App.jsx y Listado.jsx. Estan invitados a mirar los demas archivos para investigar futuras funciones y herramientas que se aprenderan a lo largo del curso.

### No hay codigo incorrecto

Es decir, que intenten refactorizar con lo que saben, lo demas se ira aprendiendo.

### Pasos para correr el proyecto

Relizar primero `npm install`
Relizar segundo `npm start`